"""
    Input : test_tuple = (4, 5, ‘Gfg’, 7.7, ‘Best’), data_type = str
Output : [4, 5, 7.7]

Input : test_tuple = (4, 5, ‘Gfg’, 7.7, ‘Best’), data_type = float
Output : [4, 5, ‘Gfg’, ‘Best’]
"""
test_tuple = (4, 5, 'Gfg', 7.7, 'Best')
data_type = str
print([a  for a in test_tuple if not isinstance(a,data_type) ])