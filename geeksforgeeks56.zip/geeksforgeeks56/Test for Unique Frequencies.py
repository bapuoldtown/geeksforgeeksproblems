"""
    Input : test_list = [4, 3, 2]
Output : False
Explanation : All have 1 as frequency, hence duplicacy, hence False

Input : test_list = [4, 3, 3, 2, 2, 2]
Output : True
Explanation : 1, 2, 3 are frequecies of 4, 3, 2 respectively, unique, hence True
"""

test_list = [4, 3, 3, 2, 2, 2]

tlist=[test_list.count(i) for i in test_list]
if len(set(tlist)) == 1:
    print(True)
else:
    print(False)