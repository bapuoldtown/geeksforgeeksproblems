"""
    Input : test_tuple = (1, 2, 4, 5, 6)
Output : (1, 4, 6)

Input : test_tuple = (1, 2, 4)
Output : (1, 4)
"""
test_tuple=(1, 2, 4, 5, 6)
list_tuple=list(test_tuple)
print(tuple([a for a in (j for i,j in enumerate(test_tuple) if i%2 == 0)]))


    


