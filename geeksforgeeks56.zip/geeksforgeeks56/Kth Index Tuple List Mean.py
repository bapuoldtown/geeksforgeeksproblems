"""
    Input : test_list = [(‘Gfg’, 1), (‘is’, 5), (‘best’, 7)], K = 1
Output : 4.333333333333333

Input : test_list = [(‘Gfg’, 7), (‘best’, 7)], K = 1
Output : 7
"""

from statistics import mean
test_list = [('Gfg', 1), ('is', 5), ('best', 7)]
K = 1

print(round(mean(i[K] for i in test_list),2))

'''Method #2 : Using sum() + len() + generator expression'''

print(sum([i[K] for i in test_list])/len([i[K] for i in test_list]))