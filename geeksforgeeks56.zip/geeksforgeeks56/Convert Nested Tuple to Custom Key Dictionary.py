"""
    Input : test_tuple = ((1, ‘Gfg’, 2), (3, ‘best’, 4)), keys = [‘key’, ‘value’, ‘id’]
Output : [{‘key’: 1, ‘value’: ‘Gfg’, ‘id’: 2}, {‘key’: 3, ‘value’: ‘best’, ‘id’: 4}]

Input : test_tuple = test_tuple = ((1, ‘Gfg’), (2, 3)), keys = [‘key’, ‘value’]
Output : [{‘key’: 1, ‘value’: ‘Gfg’}, {‘key’: 2, ‘value’: 3}]
"""
test_tuple = ((1, 'Gfg', 2), (3, 'best', 4))
keys = ['key', 'value', 'id']

res_list=[]

for a in test_tuple:
    tdict={}
    for i,j in zip(keys,a):
        tdict[i]=j
    res_list.append(tdict)

print(res_list)

"""Dictionary Comprehension"""
print([{i:j for i,j in zip(keys,a)} for a in test_tuple])


