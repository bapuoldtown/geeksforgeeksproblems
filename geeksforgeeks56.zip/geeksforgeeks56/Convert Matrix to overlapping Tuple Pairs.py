"""
    Input : test_list = [[5, 6, 3], [8, 6, 2], [2, 5, 1]]
Output : [(5, 6), (6, 3), (8, 6), (6, 2), (2, 5), (5, 1)]

Input : test_list = [[5, 6, 3]]
Output : [(5, 6), (6, 3)]
"""

test_list = [[5, 6, 3], [8, 6, 2], [2, 5, 1]]
rs_list=[]
for idx in test_list:
    for a in range(len(idx)-1):
        rs_list.append(tuple(idx[a:a+2]))


print(rs_list)
        