"""
    nput : test_list = [(‘Gfg’, 1), (‘is’, 1), (‘best’, 1), (‘for’, 1), (‘geeks’, 1)]
Output : [0, 5, 0, 0, 0, 0]

Input : test_list = [(‘Gfg’, 5), (‘is’, 5)]
Output : [0, 0, 0, 0, 0, 2]
"""

a=50
b=50

print(a&b)