test_list = [5, 6, 7]
  
# printing original list
print("The original list is : " + str(test_list))
  
# initializing tuple 
test_tup = (9, 10)

#adding tuple to a list below

test_list+=test_tup

print(test_list)

