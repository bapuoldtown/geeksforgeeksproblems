"""
    Input : test_list = [(‘Gfg’, 3), (‘is’, 4), (‘best’, 1), (‘for’, 10), (‘geeks’, 11)], key = ‘geeks’
Output : (‘for’, 10)

Input : test_list = [(‘Gfg’, 3), (‘is’, 4), (‘best’, 1), (‘for’, 10), (‘geeks’, 11)], key = ‘is’
Output : (‘Gfg’, 3)
"""
#This Solution is more comprehensive that geeks for geeks solution

test_list = [('geeks', 'Hi',24), ('is', 4), ('best', 1), ('for', 10), ('geeks', 11)]
key = 'geeks'
count=0
for a in range(len(test_list)):
    if key not in list(test_list[a]):
        count+=1
    else:
        if a > 0: 
            for b in list(test_list[a-1]):
                if str(b).isnumeric():
                    print(b)
                    break
            break
        elif a == 0:
            for b in test_list[0]:
               if str(b).isnumeric():
                   print(b)
                   break
            break




