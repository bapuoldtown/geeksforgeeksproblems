"""
    Input : test_list = [3, 4, 5, 2, 1], K = 2
Output : [1, 5, 3]
Explanation : Every 2nd elements are extracted from rear starting from 1.

Input : test_list = [3, 4, 5], K = 1
Output : [5, 4, 3]
Explanation : Every elements are extracted from rear starting from 1.
"""

test_list = [3, 4, 5, 2, 1]
K = 2

print(test_list[::-1][::2])