"""
    Input : test_str = “geksefokesgergeeks”, arg_str = “geeks”
Output : 3
Explanation : “geeks” can be created 3 times using string characters.

Input : test_str = “gefroksefokesgergeeks”, arg_str = “for”
Output : 2
Explanation : “for” can be created 2 times using string characters.
"""
from collections import Counter
test_str = "gefroksefokesgerrgeeks"
arg_str = "for"

test_dict={arg_str[i]:test_str.count(arg_str[i]) for i in range(len(arg_str))}

print(min(list(set(test_dict.values()))))


print(Counter(arg_str))





