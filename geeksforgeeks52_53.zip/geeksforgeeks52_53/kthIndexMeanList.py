"""
    nput : test_list = [(‘Gfg’, 1), (‘is’, 5), (‘best’, 7)], K = 1
Output : 4.333333333333333

Input : test_list = [(‘Gfg’, 7), (‘best’, 7)], K = 1
Output : 7
"""
from statistics import mean
test_list = [('Gfg', 4), ('is', 18), ('best', 2), ('for', 5), ('geeks', 1)]
  
print("The original list is : " + str(test_list))
  
K = 1
print(sum(i[K] for i in test_list)/len([a[K] for a in test_list if a[K]]))

