"""
Input : {“Gfg” : [6, 8, 10], “is” : [8, 10, 12, 16], “Best” : [10, 16, 14, 6]}
Output : {‘Gfg’: True, ‘is’: True, ‘Best’: True}
Explanation : All lists have even numbers.

Input : {“Gfg” : [6, 5, 10], “is” : [8, 10, 11, 16], “Best” : [10, 16, 14, 6]}
Output : {‘Gfg’: False, ‘is’: False, ‘Best’: True}
Explanation : Only “Best” has even numbers.
"""

test_dict={"Gfg" : [6, 5, 10], "is" : [8, 10, 12, 16], "Best" : [10, 16, 14, 6]}
result_dict=dict()

for i,j in test_dict.items():
    if all(( a%2 == 0 for a in test_dict[i])):
        result_dict[i]=True
    else:
        result_dict[i]=False


print(result_dict)



