"""
Input : test_list = [(5, 6), (2, 4), (5, 7), (2, 5)], sub_list = [5, 4]
Output : [(5, 6, 5, 4), (2, 4, 5, 4), (5, 7, 5, 4), (2, 5, 5, 4)]
"""

test_list = [(5, 6), (2, 4), (5, 7), (2, 5)] 
sub_list = [7, 2, 4, 6] 

print([(*i,*sub_list)for i in test_list])