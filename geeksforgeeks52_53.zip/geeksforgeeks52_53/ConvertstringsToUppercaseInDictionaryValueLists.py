"""
    Input : {“Gfg” : [“ab”, “cd”], “Best” : [“gh”], “is” : [“kl”]}
Output : {‘Gfg’: [‘AB’, ‘CD’], ‘Best’: [‘GH’], ‘is’: [‘KL’]}
Explanation : All value lists strings are converted to upper case.

Input : {“Gfg” : [“ab”, “cd”, “Ef”]}
Output : {‘Gfg’: [‘AB’, ‘CD’, “EF”]}
Explanation : All value lists strings are converted to upper case, already upper case have no effect.
"""

inputDict={"Gfg" : ["Ab", "cd"], "Best" : ["gh"], "is" : ["Kl"]}
for i in inputDict.keys():
    inputDict[i]=[a.upper() for a in inputDict[i]]

print(inputDict)

'''Using Map and upper function'''
inputDict1={"Gfg" : ["Ab", "cd"], "Best" : ["gh"], "is" : ["Kl"]}
for a in inputDict1.keys():
    inputDict1[a]=list(map(str.upper,inputDict1[a]))
print(inputDict1)