"""
    Input : test_list = [“gfgBest”, “forGeeks”, “andComputerScienceStudents”]
Output : [‘gfg Best’, ‘for Geeks’, ‘and Computer Science Students’]
Explanation : Words segregated by Capitals.

Input : test_list = [“ComputerScienceStudentsLoveGfg”]
Output : [‘Computer Science Students Love Gfg’]
Explanation : Words segregated by Capitals.
"""

test_list = ["GfgBest", "forGeeks", "andComputerScienceStudents"]

result_list=[]

for a in test_list:
    tstr=""
    for i in range(len(a)):
        if a[i].islower():
            tstr+=a[i]
        elif a[i].isupper() and i!=0:
            tstr+=" "+a[i]
        elif a[i].isupper() and i ==0:
            tstr+=a[i]
    result_list.append(tstr)

print(result_list)




