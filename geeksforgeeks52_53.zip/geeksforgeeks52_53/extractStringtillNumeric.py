"""
    Input : test_str = “geeksforgeeks7 is best”
Output : geeksforgeeks
Explanation : All characters before 7 are extracted.

Input : test_str = “2geeksforgeeks7 is best”
Output : “”
Explanation : No character extracted as 1st letter is numeric.
"""

test_str = "geeksforgeeks7 is best"
result_str=""



for i in range(len(test_str)):
    if not test_str[i].isdigit():
        result_str+=test_str[i]
    else:
        break
print(result_str)



