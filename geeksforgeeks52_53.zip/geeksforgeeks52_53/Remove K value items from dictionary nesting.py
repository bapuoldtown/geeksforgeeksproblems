"""
    Input : [{“Gfg” : {“a” : 5, “b” : 8, “c” : 9}}, {“is” : {“j” : 8, “k” : 10}}, {“Best” : {“i” : 16}}], K = 8
Output : [{‘a’: 5}, {‘c’: 9}, {‘k’: 10}, {‘i’: 16}]
Explanation : All the keys with value 8, (“b”, “j”) has been removed.

Input : [{“Gfg” : {“a” : 5, “b” : 8, “c” : 9}}, {“is” : {“j” : 8, “k” : 10}}, {“Best” : {“i” : 16}}], K = 5
Output : [{‘c’: 9}, {‘k’: 10}, {‘i’: 16}, {“j” : 8}, {“b” : 8}]
Explanation : “a” with 5 as value removed.
"""
test_list=[{"Gfg" : {"a" : 5, "b" : 8, "c" : 9}}, {"is" : {"j" : 8, "k" : 10}}, {"Best" : {"i" : 16}}]
K = 8
res_list=[]
for a in test_list:
    for i in a.keys():
        for j,l in a[i].items():
            tdict={}
            if l != K:
                tdict[j]=l
                res_list.append(tdict)
print(res_list)