"""
    Input : test_dict = {“gfg” : 1, “is” : 1, “best” : 1, “for” : 1, “geeks” : 1}
Output : {“best” : 1, “is” : 1, “for” : 1, “geeks” : 1, “gfg” : 1}
Explanation : All values are equal, hence lexicographically sorted keys.

Input : test_dict = {“gfg” : 5, “is” : 4, “best” : 3, “for” : 2, “geeks” : 1}
Output : {“gfg” : 5, “is” : 4, “best” : 3, “for” : 2, “geeks” : 1}
Explanation : All values are different, hence descending ordered sorted.
"""
test_dict = {"gfg" : 5, "is" : 4, "best" : 3, "for" : 2, "geeks" : 1}

if len(set(list(test_dict.values()))) == 1:
    print({a:test_dict.get(a) for a in sorted(test_dict.keys())})
else:
    print({a[0]:a[1]for a in sorted(test_dict.items(),key=lambda x:x[1])})


