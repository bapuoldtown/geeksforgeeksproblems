    """
    Input : test_list = [1, 3, 5, 6, 7, 9]
Output : ([1], [3], [5], [6], [7], [9])

Input : test_list = [1]
Output : ([1])
    """



test_list = [1, 3, 5, 6, 7, 9]

print(tuple([[i] for i in test_list]))