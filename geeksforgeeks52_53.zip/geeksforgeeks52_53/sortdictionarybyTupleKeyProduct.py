"""
    Input : test_dict = {(2, 3) : 3, (6, 3) : 9, (8, 4): 10, (10, 4): 12}
Output : {(2, 3) : 3, (6, 3) : 9, (8, 4): 10, (10, 4): 12}
Explanation : 6 < 18 < 32 < 40, key products hence retains order.

Input : test_dict = {(20, 3) : 3, (6, 3) : 9, (8, 4): 10, (10, 4): 12}
Output : {(6, 3) : 9, (8, 4): 10, (10, 4): 12, (20, 3) : 3, }
Explanation : 18 < 32 < 40 < 60, key products hence adjusts order.
"""

test_dict = {(2, 3) : 3, (6, 0) : 9, (8, 4): 10, (10, 4): 12}

print({i:test_dict[i] for i in sorted(test_dict.keys(),key=lambda a:a[0]*a[1],reverse=True)})
