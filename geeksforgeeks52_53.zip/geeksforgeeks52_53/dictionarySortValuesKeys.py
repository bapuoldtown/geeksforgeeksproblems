"""
Input : test_dict = {“gfg” : 1, “is” : 1, “best” : 1, “for” : 1, “geeks” : 1}
Output : {“best” : 1, “is” : 1, “for” : 1, “geeks” : 1, “gfg” : 1}
Explanation : All values are equal, hence lexicographically sorted keys.

Input : test_dict = {“gfg” : 5, “is” : 4, “best” : 3, “for” : 2, “geeks” : 1}
Output : {“gfg” : 5, “is” : 4, “best” : 3, “for” : 2, “geeks” : 1}
Explanation : All values are different, hence descending ordered sorted.
"""
test_dict = {"gfg" : 1, "is" : 1, "best" : 1, "for" : 1, "geeks" : 1}

sorted_tuple_list=[(i,j)for i,j in test_dict.items()]


print(sorted(test_dict.items(),key=lambda a:(a[0],a[1])))
        


