"""
    Input : 
Output : {‘Gfg’: [‘AB’, ‘CD’], ‘Best’: [‘GH’], ‘is’: [‘KL’]}
Explanation : All value lists strings are converted to upper case.

Input : {“Gfg” : [“ab”, “cd”, “Ef”]}
Output : {‘Gfg’: [‘AB’, ‘CD’, “EF”]}
Explanation : All value lists strings are converted to upper case, already upper case have no effect.
"""

test_dict={"Gfg" : ["ab", "cd"], "Best" : ["gh"], "is" : ["kl"]}

print({i:list(map(str.upper,test_dict[i]))for i,j in test_dict.items()})
