test_dict = {"Gfg" : 4, "is" : 4, "Best" : 4, "for" : 4, "Geeks" : 4}

print(float(sum(list(test_dict.values()))/len(list(test_dict.values()))))