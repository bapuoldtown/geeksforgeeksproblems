"""
    Input : test_list = [“Gfg is good for learning”, “Gfg is lor geeks”, “I love G4G”], K = l
Output : [‘learning’, ‘love’]
Explanation : All elements with L as starting letter are extracted.

Input : test_list = [“Gfg is good for learning”, “Gfg is for geeks”, “I love G4G”], K = m
Output : []
Explanation : No words started from “m” hence no word extracted.
"""
test_list = ["Gfg is good for learning", "Gfg is for geeks", "I love G4G"]
K = 'l'


final_list=[]

for a in test_list:
    tlist=a.split()
    for i in tlist:
        if i[0] == K:
            final_list.append(i)
        else:
            pass

#print(final_list)


''' Lets use a Generator Function'''

print([k for k in (c  for b in test_list for c in b.split() if c[0] == K)])


        


