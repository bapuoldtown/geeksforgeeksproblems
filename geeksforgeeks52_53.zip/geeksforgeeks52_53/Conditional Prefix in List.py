"""
    Input : test_list = [45, 53, 76, 86, 3, 49], pref_1 = “LOSE-“, pref_2 = “WIN-”
Output : [‘LOSE-45’, ‘WIN-53’, ‘WIN-76’, ‘WIN-86’, ‘LOSE-3’, ‘LOSE-49’]
Explanation : All 50+ are prefixed as “WIN-” and others as “LOSE-“.

Input : test_list = [78, 53, 76, 86, 83, 69], pref_1 = “LOSE-“, pref_2 = “WIN-”
Output : [‘WIN-78’, ‘WIN-53’, ‘WIN-76’, ‘WIN-86’, ‘WIN-83’, ‘WIN-69’]
Explanation : All are 50+ hence prefixed “WIN-“.
"""

test_list = [45, 53, 76, 86, 3, 49]
pref_1 = "LOSE-"
pref_2 = "WIN-"

def gfunc(a):
    if a > 50:
        return "WIN-"+str(a)
    return "LOSE-"+str(a)

print(list(map(gfunc,test_list)))

"""Use List Comprehensions"""
print(["WIN-"+str(b) if b > 50 else "LOSE-"+str(b) for b in test_list])


