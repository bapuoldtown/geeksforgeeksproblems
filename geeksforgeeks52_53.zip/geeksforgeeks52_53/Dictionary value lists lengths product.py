"""
    Input : test_dict = {‘Gfg’ : [6, 5, 9, 3], ‘is’ : [1, 3, 4], ‘best’ :[9, 16]}
Output : 24
Explanation : 4 * 3 * 2 = 24. Length of lists are 4, 3, and 2.

Input : test_dict = {‘Gfg’ : [6, 5, 3], ‘is’ : [1, 3, 4], ‘best’ :[9, 16]}
Output : 18
Explanation : 3 * 3 * 2 = 18. Length of lists are 3, 3, and 2.
"""
from functools import reduce
test_dict = {'Gfg' : [6, 5, 9, 3], 'is' : [1, 3, 4], 'best' :[9, 16]}
res=1
print(int(reduce(lambda a,b:a*b,[len(test_dict[i]) for i in test_dict.keys()])))


