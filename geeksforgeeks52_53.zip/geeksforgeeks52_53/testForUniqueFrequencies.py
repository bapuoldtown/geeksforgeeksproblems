test_list = [4, 3, 2]

temp=[test_list.count(a) for a in set(test_list)]

print(len(temp) == len(set(temp)))