    """
    Input : test_list = [(‘Gfg’, 10), (‘best’, 3), (‘CS’, 8), (‘Geeks’, 7)], ord_list = [‘Geeks’, ‘best’, ‘CS’, ‘Gfg’]
Output : [(‘Geeks’, 7), (‘best’, 3), (‘CS’, 8), (‘Gfg’, 10)]

Input : test_list = [(‘best’, 3), (‘CS’, 8), (‘Geeks’, 7)], ord_list = [‘Geeks’, ‘best’, ‘CS’]
Output : [(‘Geeks’, 7), (‘best’, 3), (‘CS’, 8)]
    """

test_list = [('Gfg', 10), ('best', 3), ('CS', 8), ('Geeks', 7)]
ord_list = ['Geeks', 'best', 'CS', 'Gfg']
test_dict=dict(test_list)

print([(i,test_dict.get(i,None)) for i in ord_list])