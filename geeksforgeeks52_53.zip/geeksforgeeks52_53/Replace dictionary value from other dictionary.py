"""
    Input : test_dict = {“Gfg” : 5, “is” : 8, “Best” : 10, “for” : 8, “Geeks” : 9},
updict = {“Geeks” : 10, “Best” : 17}
Output : {‘Gfg’: 5, ‘is’: 8, ‘Best’: 17, ‘for’: 8, ‘Geeks’: 10}
Explanation : “Geeks” and “Best” values updated to 10 and 17.

Input : test_dict = {“Gfg” : 5, “is” : 8, “Best” : 10, “for” : 8, “Geeks” : 9},
updict = {“Geek” : 10, “Bet” : 17}
Output : {‘Gfg’: 5, ‘is’: 8, ‘Best’: 10, ‘for’: 8, ‘Geeks’: 9}
Explanation : No values matched, hence original dictionary.
"""

test_dict = {"Gfg": 5, "is" : 8, "Best" : 10, "for" : 8, "Geeks" : 9}
updict = {"Geeks" : 10, "Best" : 17}


for a in updict.keys():
    if a in test_dict:
        test_dict[a]=updict[a]


print(test_dict)

